package com.example.boi.mela;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoiMelaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoiMelaApplication.class, args);
	}

}
