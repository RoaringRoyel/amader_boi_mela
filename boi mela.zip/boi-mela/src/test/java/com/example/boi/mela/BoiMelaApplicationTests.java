package com.example.boi.mela;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoiMelaApplicationTests {

	@Test
	void contextLoads() {
	}

}
